<script src="<?php echo e(asset('assets/js/phosphor-icons.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php /**PATH /Users/mousamjain/Documents/anvogue-laravel/resources/views/partials/scripts.blade.php ENDPATH**/ ?>